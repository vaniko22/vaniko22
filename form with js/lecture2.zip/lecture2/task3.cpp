#include <iostream>
#include <string>
using namespace std;


int main(){
	
	int arr[20];
	int sum = 0;
	
	cout << "Enter a numbers: " << endl;
	for(int i = 0; i < 20; i++){
		cin >> arr[i];
	}
	
	for(int j = 0; j < 20; j++){
		if(arr[j] < 5){
			cout << "This product price is lower than 5 : " << arr[j] << endl;
		}
		sum += arr[j];
	}
	
	int avg = sum / 20;
	cout << "Avarange price is: " << avg << endl;
	
	for(int n = 0; n < 20; n++){
		if(arr[n] > avg){
			cout << "This product price is more than avg: " << arr[n] << endl;
		}
	}
	
	return 0;	
}
