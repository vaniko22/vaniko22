#include <iostream>
#include <string>
using namespace std;

int main(){
	
	int arr[5];
	
	
	cout << "Enter 5 number: " << endl;
	for(int i = 0; i < 5; i++){
		cin >> arr[i];
	}
	
	
	int min = arr[0];
	int nextMin = arr[0];
		
	for(int j = 0; j < 5; j++){
		if(arr[j] < min){
			min = arr[j];
		}
	}
	
	for(int n = 0; n < 5; n++){
		if(arr[n] == min){
			continue;
		}
		
		if(arr[n] < nextMin){
			nextMin = arr[n];
		}
	}
	

	
	cout << "This number is minumum after minumum in this array:  " << nextMin << endl;
	
	
	
	
	
	return 0;
}



