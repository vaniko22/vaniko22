#include <iostream>
#include <string>
using namespace std;



int main(){
	
	string a = "!";
	string b;
	cout << "Enter symbols: " << endl; 
	
	
	while(b != a){
		cin >> b;
		if(b == "a" || b == "e" || b == "i" || b == "o" || b == "u"){
			cout << "xmovania" << endl;
		}else{
			cout << "tanxmovania" << endl;
		}
	}
		
}
