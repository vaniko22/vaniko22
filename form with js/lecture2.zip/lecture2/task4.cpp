#include <iostream>
#include <string>
using namespace std;


int main(){
	
	int a;
	cout << "Enter quantity of subjects: " << endl;
	cin >> a;	
	int arr[a];
	

	cout << "Enter subject points:  " << endl;
	for(int i = 0; i < a; i++){
		cin >> arr[i];
	}
	
	int mx = arr[0];
	int min = arr[0];
	
	for(int j = 0; j < a; j++){
		if(arr[j] > mx){
			mx = arr[j];
		}else if(arr[j] < min){
			min = arr[j];
		}
	}
	
	cout << "Maximum value is: " << mx << endl << "Minimum value is: " << min << endl;
	
	return 0;
}
